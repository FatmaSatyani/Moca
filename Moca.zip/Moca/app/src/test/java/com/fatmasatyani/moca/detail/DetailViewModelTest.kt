package com.fatmasatyani.moca.detail

import com.fatmasatyani.moca.utils.Data
import junit.framework.TestCase.assertEquals
import junit.framework.TestCase.assertNotNull
import org.junit.Before
import org.junit.Test

class DetailViewModelTest {

    private lateinit var viewModel: DetailViewModel

    private val data = Data.generateMovie()[0]
    private val data2 = Data.generateTvShow()[0]

//  Movie Testing
    @Before
    fun setUpMovie() {
        viewModel = DetailViewModel()
        viewModel.setSelectedMovie("M1")
    }

    @Test
    fun movieResult(){
        viewModel.setSelectedMovie("M1")
        val movie = viewModel.getMovie("M1")
        assertNotNull(movie)
        assertEquals(data.movieId, movie.movieId)
        assertEquals(data.movieTitle, movie.movieTitle)
        assertEquals(data.movieDisplayPicture, movie.movieDisplayPicture)
        assertEquals(data.movieDescription, movie.movieDescription)
        assertEquals(data.movieTrailer, movie.movieTrailer)
        assertEquals(data.detailEntity, movie.detailEntity)
    }

//  Tv Show Testing
    @Before
    fun setUpTvShow() {
        viewModel = DetailViewModel()
        viewModel.setSelectedTvShow("T1")
    }

    @Test
    fun tvShowResult() {
        viewModel.setSelectedTvShow("T1")
        val tvShow = viewModel.getTvShow("T1")
        assertNotNull(tvShow)
        assertEquals(data2.tvShowId, tvShow.tvShowId)
        assertEquals(data2.tvShowTitle, tvShow.tvShowTitle)
        assertEquals(data2.tvShowDisplayPicture, tvShow.tvShowDisplayPicture)
        assertEquals(data2.tvShowDescription, tvShow.tvShowDescription)
        assertEquals(data2.tvShowTrailer, tvShow.tvShowTrailer)
        assertEquals(data2.detailEntity, tvShow.detailEntity)
    }
}