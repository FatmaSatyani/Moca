package com.fatmasatyani.moca.home

import androidx.recyclerview.widget.RecyclerView
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions
import androidx.test.espresso.action.ViewActions.click
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.contrib.RecyclerViewActions
import androidx.test.espresso.matcher.ViewMatchers.*
import androidx.test.ext.junit.rules.ActivityScenarioRule
import com.fatmasatyani.moca.R
import com.fatmasatyani.moca.utils.Data
import org.junit.Rule
import org.junit.Test

class HomeActivityTest {

    private val dummyMovie = Data.generateMovie()
    private val dummyTvShow = Data.generateTvShow()

    @get:Rule
    var activityRule = ActivityScenarioRule(HomeActivity::class.java)

//    Movie Testing
    @Test
    fun loadMovie() {
        onView(withId(R.id.rv_movies))
            .check(matches(isDisplayed()))
        onView(withId(R.id.rv_movies))
            .perform(RecyclerViewActions.scrollToPosition<RecyclerView.ViewHolder>(dummyMovie.size))
    }

    @Test
    fun loadMovieDetail() {
        onView(withId(R.id.rv_movies))
            .perform(RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder> (0,click()))
        onView(withId(R.id.detail_toolbar_layout))
            .check(matches(isDisplayed()))
        onView(withId(R.id.detail_toolbar_layout))
            .check(matches(withContentDescription(dummyMovie[0].movieTitle)))
    }

    @Test
    fun loadTvShow() {
        onView(withText("TV SHOW"))
            .perform(ViewActions.click())
        onView(withId(R.id.rv_tvShows))
            .check(matches(isDisplayed()))
        onView(withId(R.id.rv_tvShows))
            .perform(RecyclerViewActions.scrollToPosition<RecyclerView.ViewHolder>(dummyTvShow.size))
    }
    @Test
    fun loadTvShowDetail() {
        onView(withText("TV SHOW"))
            .perform(ViewActions.click())
        onView(withId(R.id.rv_tvShows))
            .perform(RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder> (0,click()))
        onView(withId(R.id.detail_toolbar_layout))
            .check(matches(isDisplayed()))
        onView(withId(R.id.detail_toolbar_layout))
            .check(matches(withContentDescription(dummyTvShow[0].tvShowTitle)))
    }

}