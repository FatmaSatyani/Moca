package com.fatmasatyani.moca.data

data class DetailEntity (
    val position: String?,
    val name: String
        )